

"Requried libraries"
import os
from nltk.tree import Tree
from nltk.draw.tree import TreeView

import xml.etree.ElementTree as ET
import XmlClass
import docx
from docx import Document
import re


##parsedtree_rep=input('parsed tree representation ? Y/N ')


"Compression rate"
"the compression system is capable of producing the desired compression rate"
"taking a compression rate between 0 to 100%"

CR=input('enter Compression rate ')
CR=int(CR)
CR=100-CR
##
subtxt=XmlClass.XmlTree.element_subtree_text
func=XmlClass.XmlTree


def compression_rate(original_sent,compressed_sent):
    'compute the overall compression rate for 2 sentences'
    'original sentence must be added first'

    original_sent_length=len(original_sent.split())
    compressed_sent_length=len(compressed_sent.split())
    compressionrate=round(100-((compressed_sent_length/original_sent_length)*100),2)
    return compressionrate



def compressed_rate(original_sent,compressed_part):
    'Compute the given part percentage of whole sentence'
    
    original_length=len(original_sent.split())
    com_part_length=len(compressed_part.split())
    compression_rate=round(((com_part_length/original_length)*100),2)
    return compression_rate


"""The input file containing the XML consituency parse format of
any number of Persian sentences with /n between them"""

path='test.xml'
parse=XmlClass.XmlTree(path)
root=parse.root



"Compression rules (Mian body of the system)"

counter=0
for i in root.iter():
    if i.tag=='S':
        counter=counter+1
        newroot=i                                                                                                                                                                                                                                         
        original_sent=subtxt(newroot)
        depth=XmlClass.XmlTree.subtree_elements_depth(newroot)
        
        remove_list=[]       
        sub_remove=[]
        applied_rule=[]
        '---------------------------------------------------------------------------'
        'rule no.1'        
        'Removes a PP followed by a comma'
        '(PP) -> PP PUNC'
        
        depth=XmlClass.XmlTree.subtree_elements_depth(newroot)
        for element in newroot.iter():
            if element.tag=='PP':
                children=list(element)         
                if children[0].tag=='PP' and children[-1].tag=='PUNC':
                    topparent=parse.parent_node(element)
                    if topparent!=None:
                        sister=parse.sister_node(element)
                        if len(sister)>0:    
                            if sister[0].tag!='V' and sister[0].tag!='MV':
                                if compressed_rate(subtxt(newroot),subtxt(element))<80:
                                    remove_list.append(element)
                                    topparent.remove(element)
                                
                            com_form=subtxt(newroot)
                            rate=compression_rate(original_sent,com_form)
                            if rate>CR:
                                break
        com_form=subtxt(newroot)
        rate=compression_rate(original_sent,com_form)
        if rate>CR:
            continue
                            



        '----------------------------------------------------------------------------'
        'rule no.3'
        'Reomves PP element'
        '(PP) -> PREP DP'
        'Limitations: 1-if sister-node has a verbal element it is not removed'
        for element in newroot.iter():
            if element.tag=='PP':
                children=list(element)
                if len (children)==2:
                    if children[0].tag=='PREP' and children[1].tag=='DP':
                        parent=parse.parent_node(element)
                        if parent!=None:
                            search=re.search('VP',parent.tag)
    ##                        print(search)
                            if search==None:
                                if parent!=None:
                                    if compressed_rate(subtxt(newroot),subtxt(element))<80:
                                        parent.remove(element)
                                com_form=subtxt(newroot)
                                rate=compression_rate(original_sent,com_form)
                                if rate>CR:
                                    break

        com_form=subtxt(newroot)
        rate=compression_rate(original_sent,com_form)
        if rate>CR:
            continue


        '----------------------------------------------------------------------------'
        'rule no.2'
        'Removes PP within an NP element'
        'NP -> NP (PP)'
        'Limitations: 1-if parent NP is the sister of a V or MV it is not removed'

        for element in newroot.iter():
            if element.tag=='NP':
                sister=parse.sister_node(element)
                if len(sister)>0:
                    if sister[0].tag!='V' and sister[0].tag!='MV':
                        children=list(element)
                        if len(children)==2:
                            if children[0].tag=='NP' and children[1].tag=='PP':
                                if compressed_rate(subtxt(newroot),subtxt(children[1]))<80:
                                    element.remove(children[1])
                                com_form=subtxt(newroot)
                                rate=compression_rate(original_sent,com_form)
                                if rate>CR:
                                    break
        com_form=subtxt(newroot)
        rate=compression_rate(original_sent,com_form)
        if rate>CR:
            continue


        '-----------------------------------------------------------------------------'
        'rule no.4'
        'Removes PP element within a VP if it is a specific type of PP'
        'VP -> (PP) VP and (PP) -> PREP NP'
        

        for element in newroot.iter():
            if element.tag=='VP':
                children=list(element)
                if len(children)==2:
                    if children[0].tag=='PP' and children[1].tag=='VP':
                        children_PP=list(children[0])
                        if len(children_PP)==2:
                            if children_PP[0].tag=='PREP' or children_PP[0].tag=='MPREP' and children_PP[1].tag=='NP':
                                remove_list.append(children[0])
                                if compressed_rate(subtxt(newroot),subtxt(children[0]))<80:
                                    element.remove(children[0])
                                    com_form=subtxt(newroot)
                                    rate=compression_rate(original_sent,com_form)
                                    if rate>CR:
                                        break
                        
        com_form=subtxt(newroot)
        rate=compression_rate(original_sent,com_form)
        if rate>CR:
            continue
##

        '--------------------------------------------------------------------------------'
        'rule no.14'
        '(PP_C)-> CONJ PPC'
        'Limitations:1-if PP_C parent is a PP_C parent it must not be removed'
        '            2-if PP_C sister is a "V" or "MV" element it must not be removed'

        for element in newroot.iter():
            if element.tag=='PP_C':
                parent=parse.parent_node(element)
                if parent!=None:
                    if parent.tag!='PP_C':
                        children=list(element)
                        if len(children)==2:
                            if children[0].tag=='CONJ' and children[1].tag=='PP':
                                sister=parse.sister_node(element)
                                if len(sister)==1:
                                    if sister[0].tag!='V' and sister[0].tag!='MV':
                                        if compressed_rate(subtxt(newroot),subtxt(element))<80:
                                            parent.remove(element)
                                
                    else:
                        topparent=parse.parent_node(parent)
                        sister=parse.sister_node(parent)
                        if len(sister)==1:     
                            if sister[0].tag!='V' and sister[0].tag!='MV':
                                if compressed_rate(subtxt(newroot),subtxt(parent))<80:
                                    topparent.remove(parent)



        '--------------------------------------------------------------------------------'
        'rule no.7'
        'This rule removes all ADJPC nodes with the below considerations'
        'Limitations 1-If sister node of ADJPC Contains Verbal element, ADJPC must not be removed'
        '            2-If the word before ADJPC ends in "ی" letter, this letter must be removed'


        for element in newroot.iter():
            if element.tag=='ADJP_C':                      #this is ADJP-C in normal corpus
                sister=parse.sister_node(element)
                parent=parse.parent_node(element)
                pre=parse.previous_node(element)
                if sister!=None and parent!=None:
                    if parent.tag!='ADJP_C':
                        if len(sister)==1:
                            match=re.search('V',sister[0].tag)
                            if match==None:
                                parent=parse.parent_node(element)                
                                if parent!=None:
                                    if compressed_rate(subtxt(newroot),subtxt(element))<80:
                                        parent.remove(element)
                                        
                                        newl=[]
                                        for k in pre.iter():
                                            newl.append(k)

                                        txtlist=list(newl[-1].text)
                                        if txtlist[-1]=='ی':
                                            txtlist.remove(txtlist[-1])
                                            txt=''.join(txtlist)
                                            newl[-1].text=txt

                                        com_form=subtxt(newroot)
                                        rate=compression_rate(original_sent,com_form)
                                        if rate>CR:
                                            break

        com_form=subtxt(newroot)
        rate=compression_rate(original_sent,com_form)
        if rate>CR:
            continue
        

        '-----------------------------------------------------------------------------'
        'rule no.5'
        'ADVP remove rule:'
        'searches for ADVP nodes and removes all with 3 things in consideration'
        'Limitations:1-If the node has a single word text, it should not be removed'
        "            2-If the node's parent is PP, ADVP node cannot be removed"
        "            3-If the node's sister is a CONJ both ADVP and CONJ must be removed"
##
        
        for element in newroot.iter():
            if element.tag=='ADVP':
                elementtxt=subtxt(element)
                split=elementtxt.split()
                if len(split)>1:
                    parent=parse.parent_node(element)
                    if parent!=None:
                        if parent.tag!='PP':
                            sister=parse.sister_node(element)
                            req=False
                            req2=False
                            for i in sister:
                                if i.tag=='CONJ':
                                    req=True
                                    ind=sister.index(i)
                                if i.tag=='V':
                                    req2=True
                                
                                    
                            if req==False and req2==False:
                                if compressed_rate(subtxt(newroot),subtxt(element))<80:
                                    parent.remove(element)
                                com_form=subtxt(newroot)
                                rate=compression_rate(original_sent,com_form)
                                if rate>CR:
                                    break

                            
                            elif req==True and req2==False:
                                if compressed_rate(subtxt(newroot),subtxt(element))<80:
                                    parent.remove(element)
                                    parent.remove(sister[ind])
                                com_form=subtxt(newroot)
                                rate=compression_rate(original_sent,com_form)
                                if rate>CR:
                                    break

        com_form=subtxt(newroot)
        rate=compression_rate(original_sent,com_form)
        if rate>CR:
            continue


        '-----------------------------------------------------------------------------'
        'rule no.6'
        'PP_removal'
        'removes PP element within a VP'
        
        for element in newroot.iter():
            if element.tag=='VP':
                children=list(element)
                if len(children)==2:
                    if children[0].tag=='PP' and children[1].tag=='VP':
                        if compressed_rate(subtxt(newroot),subtxt(children[0]))<80:
                            element.remove(children[0])
                            remove_list.append(children[0])
                        com_form=subtxt(newroot)
                        rate=compression_rate(original_sent,com_form)
                        if rate>CR:
                            break
                    
        com_form=subtxt(newroot)
        rate=compression_rate(original_sent,com_form)
        if rate>CR:
            continue



        '-----------------------------------------------------------------------------'
        'rule no.7'
        'ADVs remove rule'
        for element in newroot.iter():
            if element.tag=='ADV':
                parent=parse.parent_node(element)
                if parent!=None:
                    if compressed_rate(subtxt(newroot),subtxt(element))<80:
                        parent.remove(element)
                    com_form=subtxt(newroot)
                    rate=compression_rate(original_sent,com_form)
                    if rate>CR:
                        break

        com_form=subtxt(newroot)
        rate=compression_rate(original_sent,com_form)
        if rate>CR:
            continue


        '-----------------------------------------------------------------------------'
        'rule no.8'
        'ADJ removal rule'
        'Removes ADJs in Nount pharses'
        'if the previous noun ends in "ی" it must not be removed'
        for element in newroot.iter():
            if element.tag=='NP':
                children=list(element)
                for i in range(len(children)):
                    if children[i].tag=='ADJ':
                        text=subtxt(children[i-1])
                        if text[-1]!='ی':
                            if compressed_rate(subtxt(newroot),subtxt(children[i]))<80:
                                element.remove(children[i])
                            com_form=subtxt(newroot)
                            rate=compression_rate(original_sent,com_form)
                            if rate>CR:
                                break                           

        com_form=subtxt(newroot)
        rate=compression_rate(original_sent,com_form)
        if rate>CR:
            continue


        
        '-----------------------------------------------------------------------------'
        'rule no.9'
        'removes one side of "و" Conjunction'
        'Also removes words added by comma before "و" Conjunction'
        for element in newroot.iter():
            if element.tag=='CONJ':
                if subtxt(element)=='و':
                    parent=parse.parent_node(element)
                    if parent!=None:
                        children=list(parent)
                        if children[0]==element:
                            req=True
                            while req==True: 
                                topparent=parse.parent_node(parent)
                                topparent_sister=parse.sister_node(topparent)
                                if topparent!=None:
                                    if compressed_rate(subtxt(newroot),subtxt(parent))<80:
                                        topparent.remove(parent)

                                parent=parse.parent_node(topparent)

                                if topparent==None:
                                    req=False
                                    break
                                if len(topparent_sister)==0:
                                    break
                                if topparent_sister[0].tag!='PUNC' or subtxt(topparent_sister[0])!='،':
                                    req=False

                                    
                                com_form=subtxt(newroot)
                                rate=compression_rate(original_sent,com_form)
                                if rate>CR:
                                    break
                             
        com_form=subtxt(newroot)
        rate=compression_rate(original_sent,com_form)
        if rate>CR:
            continue

        
        '-----------------------------------------------------------------------------'
        'rule no.10'
        'removes one of every other conjunction'
        'Limitations: 1-does not consider "و" Conjunction (it is considered in a seperate rule'
        '             2-does not consider "که" Conjunction as it causes ungrammaticality'
        '             3-if pre-node is also a Conjunction it must be removed'
        '             4-if pre-node parent is Compound Conjunction all children must be removed'
        
        for element in newroot.iter():
            if element.tag=='CONJ':
                pre=parse.previous_node(element)
                txt=subtxt(element)
                
                if pre!=None:
                    pre_parent=parse.parent_node(pre)
                    if pre_parent.tag=='CONJ':
                        topparent=parse.parent_node(pre_parent)
                        if topparent.tag!='MCONJ':
                            children=list(topparent)
                            for j in children:
                                if compressed_rate(original_sent,subtxt(j))<70:
                                    topparent.remove(j)
                                
                if txt!='که' and txt!='و':
                    parent=parse.parent_node(element)
                    if parent!=None:
                        children=list(parent)
                        if children[-1]!=element:
                            remove_part=''
                            for i in children:
                                remove_part=remove_part+subtxt(i)+' '
                            if compressed_rate(subtxt(newroot),remove_part)<70:
                                for i in children:
                                    parent.remove(i)

                                com_form=subtxt(newroot)
                                rate=compression_rate(original_sent,com_form)
                                if rate>CR:
                                    break
                                
        com_form=subtxt(newroot)
        rate=compression_rate(original_sent,com_form)
        if rate>CR:
            continue
                                    


##

        '-----------------------------------------------------------------------------'
        'rule no.11'
        'Removing remaining PPs, if the compression rate condition has not been met yet'

        
        remove_list_final=[]
        for element in newroot.iter():
            if element.tag=='PP':
                sister=parse.sister_node(element)
                if len(sister)>0:
                    if sister[0].tag!='V' and sister[0].tag!='MV':
                        for k in depth:
                            if element==k[0]:
                                remove_list_final.insert(0,k)

            
        orgnized_remove=[]
        temp1=[]
        for j in remove_list_final:
            temp1.append(j[1])

        while len(temp1)>0:
            ind=temp1.index(max(temp1))
            orgnized_remove.append(remove_list_final[ind][0])
            remove_list_final.remove(remove_list_final[ind])
            temp1.remove(temp1[ind])

        for z in orgnized_remove:
              previous=parse.previous_node(z)
              previous_parent=parse.parent_node(previous)
              if previous!=None and previous_parent!=None:
                  if previous_parent.tag=='CONJ':
                      if compressed_rate(subtxt(newroot),subtxt(z))<70:
                          topparent=parse.parent_node(previous_parent)
                          topparent.remove(previous_parent)
                          parent=parse.parent_node(z)
                          parent.remove(z)
                      comper=subtxt(newroot)
                      rate=compression_rate(original_sent,comper)
                      if rate>CR:
                          break

                  else:
                      if compressed_rate(subtxt(newroot),subtxt(z))<70:
                          parent=parse.parent_node(z)
                          parent.remove(z)
                      comper=subtxt(newroot)
                      rate=compression_rate(original_sent,comper)
                      if rate>CR:
                          break

    
##                
"Creating and adding the compressed sentence to the output file"

"Creating the xml format of the compressed sentences"

final=ET.ElementTree(root)
final.write('Compression_Results.xml',encoding='UTF-8')    

res_file=open('Compression_Results.txt','w',encoding='utf8')
doc= Document()
No_of_sentences=counter

def string_subtraction(string1,string2):
    split1=string1.split()
    split2=string2.split()

    for i in split2:
        if split1.count(i)!=0:
            split1.remove(i)
    return split1

tree=ET.parse('test.xml')
root=tree.getroot()
new='task'



treec=ET.parse('Compression_Results.xml')
rootc=treec.getroot()
c=0

mainlist=[]
for i in root.iter():
    if i.tag=='S':
        c=c+1
        whole=''
        newroot=i
        text=subtxt(newroot)
##        text=re.sub('\u200c','',text)
        mainlist.append(text)

syslist=[]
for i in rootc.iter():
    if i.tag=='S':
        c=c+1
        newroot=i
        whole=subtxt(newroot)
##        whole=re.sub('\u200c','',whole)
        syslist.append(whole)


"calcualting the number of compressed sentences from the input file"
"creating the text and MS word outputs"
no=0
for i in range(len(mainlist)):
    if mainlist[i]!=syslist[i]:
        no=no+1
res_file.write('Number of affected sentences'+' '+'='+' '+str(no)+' '+'out of'+' '+str(len(mainlist)))
res_file.write('\n')
doc.add_paragraph('Number of affected sentences'+' '+'='+' '+str(no)+' '+'out of'+' '+str(len(mainlist)))
doc.add_paragraph('\n')
unaffected=[]
co=0
for i in range(len(mainlist)):
    co=co+1
    if mainlist[i]!=syslist[i]:
        mainlength=len((mainlist[i]).split())
        complength=len((syslist[i]).split())
        compression_rate=round(100-((complength/mainlength)*100),2)
        res_file.write(str(co))
        res_file.write('\n')
        doc.add_paragraph('-'+str(co))
        res_file.write(mainlist[i])
        res_file.write('\n')
        doc.add_paragraph(mainlist[i])
        res_file.write(syslist[i])
        res_file.write('\n')
        doc.add_paragraph(syslist[i])
        removed_part=string_subtraction(mainlist[i],syslist[i])
        res_file.write('removed words:')
        res_file.write('\n')
        doc.add_paragraph('removed words:')
        removed=''
        for i in removed_part:
            removed=removed+i+' '+','+' '
        res_file.write(removed)
        res_file.write('\n')
        doc.add_paragraph(removed)
        res_file.write('Compression Rate'+' '+'='+str(100-compression_rate))
        res_file.write('\n')
        doc.add_paragraph('Compression Rate'+' '+'='+str(100-compression_rate))
        res_file.write('-'*80)
        doc.add_paragraph('-'*80)
        res_file.write('\n')
 
##        doc.add_paragraph('\n')
    else:
        unaffected.append(co)
##        print(co)


c=0
if len(unaffected)>0:
    doc.add_paragraph('\n')
    res_file.write('\n')
    doc.add_paragraph('Number of unaffected setences'+' '+'='+' '+str(len(unaffected))+' '+'out of'+' '+str(len(mainlist)))
    res_file.write('Number of unaffected setences'+' '+'='+' '+str(len(unaffected))+' '+'out of'+' '+str(len(mainlist)))
    for i in rootc.iter():
        if i.tag=='S':
            c=c+1
            for j in unaffected:
                if c==j:
                    doc.add_paragraph('-'+str(j))
                    res_file.write(str(j))
                    res_file.write('\n')
                    doc.add_paragraph(subtxt(i))
                    res_file.write(subtxt(i))
                    res_file.write('\n')
                    
                
##                XmlClass.XmlTree.element_treeview(i)
            
doc.save('Compression_Results.docx')
res_file.close()
