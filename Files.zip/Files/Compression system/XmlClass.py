import xml.etree.ElementTree as ET
from xml.dom import minidom
import nltk
import re
from nltk.tree import Tree
from nltk.draw.tree import TreeView


class XmlTree():
    

##
    def __init__(self,xmlpath):
        self.xmlpath=xmlpath
        self.tree= ET.parse(self.xmlpath)
        self.root= (self.tree).getroot()




    def element_tag(self,element):
        
        'search element in tree and returns its tag'
        'returns None if no such element found in tree'

        root=self.root
        cond='False'
        for i in root.iter():
            if i==element:
                cond='True'
                tag=element.tag

        if cond=='True':
            return tag
        else:
            return None


    def element_text(slef,element):

        'search element in tree and returns its text'
        'Returns none if no such element found in tree'

        root=self.root
        cond='False'
        for i in root.iter():
            if i==element:
                cond='True'
                text=element.text

        if cond=='True':
            return text
        else:
            return None


    

    def xml_text(self):

        'Searches for text in all xml nodes and makes a string'
        'removes all white spaces'

        text=''
        
        for i in (self.root).iter():
            if i.text!='' and i.text!=None:
                i.text=re.sub('\s','',i.text)
                text=text+i.text+' '

        text=re.sub(' +',' ',text)
        text=re.sub('\s+$','',text)
        text=re.sub('^\s+','',text)
        return text
        


    def parent_node(self,element):
        'gets an element of Tree and returns the parent node'
        
        root=self.root
        for i in root.iter():
            for child in i:
                if child==element:
                    return i

                    


    def sister_node(self,element):
        'gets an element node of Tree and retunrs its sister/sisters'

        root=self.root
        for i in root.iter():
            for child in i:
                if child==element:
                    children=list(i)

                    for j in children:
                        if j==element:
                            children.remove(element)
                    return children



    def text_element(self,text):
        'finds the node containing the text and returns it '
        'first node that contains element will be returned as result'

        root=self.root
        for i in root.iter():
            txt=XmlTree.element_subtree_text(i)
            if txt==text:
                return i
                break


                
    def next_node(self,element):
        'gets an element,returns the next right-most element containing text'
        
        root=self.root
        for i in root.iter():
            if i==element:
                req=True
                while req==True:
                    parent=XmlTree.parent_node(self,element)
                    children=list(parent) 
                    if children[-1]!=element:
                        req=False
                        ind=children.index(element)
                        node=children[ind+1]
                    else:
                        element=parent
                                    
                
                for k in node.iter():
                    if len(list(k))==0:
                        return(k)
                        break



    def previous_node(self,element):
        'gets an element, returns the previous left_most element containing text'

        root=self.root
        for i in root.iter():
            if i==element:
                req=True
                while req==True:
                    parent=XmlTree.parent_node(self,element)
                    children=list(parent)
                    if children[0]!=element:
                        req=False
                        ind=children.index(element)
                        node=children[ind-1]

                    else:
                        element=parent
                
                List=[]
                for j in node.iter():
                    List.append(j)

                return List[-1]

                            
        

    def elements_depth(self):
        
        'finds and asign all elements depth'
        'returns a list containing elements in xml format and their depth'
        
        depth=1
        elements=[]
        elementsdepth=[]
        elements.append(self.root)
        elementsdepth.append(depth)
        elementsdepthlist=[]

        for i in (self.root).iter():
            childs=list(i)
            for j in childs:
                if elementsdepth.count(j)==0:
                    elements.append(j)
                    index=elements.index(i)
                    elementsdepth.append(elementsdepth[index]+1)            

        for i in range(len(elements)):
            depthlist=[]
            depthlist.append(elements[i])
            depthlist.append(elementsdepth[i])
            elementsdepthlist.append(depthlist)
##        print (elementsdepthlist)    
        return elementsdepthlist



    
    def subtree_elements_depth(element):
        
        'gets a subtree assigns depth to all elements within'
        'returns a list containing elements in xml format and their depth'
        
        depth=1
        elements=[]
        elementsdepth=[]
        elements.append(element)
        elementsdepth.append(depth)
        elementsdepthlist=[]

        for i in element.iter():
            childs=list(i)
            for j in childs:
                if elementsdepth.count(j)==0:
                    elements.append(j)
                    index=elements.index(i)
                    elementsdepth.append(elementsdepth[index]+1)            

        for i in range(len(elements)):
            depthlist=[]
            depthlist.append(elements[i])
            depthlist.append(elementsdepth[i])
            elementsdepthlist.append(depthlist)
##        print (elementsdepthlist)    
        return elementsdepthlist




    def element_depth(self,element):
        
        'gets an element of tree as an argument and returns element depth'
        'all elements found with such a tag in the tree will be returned as a list alongside their depth'
        
        alldepths=XmlTree.elements_depth(self)
        elementsdepth=[]
        
        for i in alldepths:
            tempelementdepth=[]
            if (i[0]).tag==element:
                if i[0].tag=='w':
                    print(i[0], i[0].text, '-> depth = ',i[1])
                    tempelementdepth.append(i[0].text)
                    tempelementdepth.append(i[1])
                else:
                    print(i[0], '=', i[0].tag, '-> depth = ', i[1])
                    tempelementdepth.append(i[0].tag)
                    tempelementdepth.append(i[1])
                elementsdepth.append(tempelementdepth)

        if (len(elementsdepth)==0):
            print('no such element found')
            return None
        else:
            return elementsdepth





    def specific_element_depth(self,element):
        'gets specific element defined by ET.parse and returns the depth'
        
        alldepths=XmlTree.elements_depth(self)
        print(element,alldepths[2])
        if element == alldepths[2][0] : print('True')
        for i in alldepths:
            if (i[0])==element:
                print (i[0], '->  depth =', i[1])
                return i[1]
            else:
                print('no such element found')
                return None


    def specific_element_depth_independent(node,element):
        'Iter through given node, and if find element returns depth, else returns None'

        node_elementsdepth=XmlTree.subtree_elements_depth(node)

        req=False
        for i in node_elementsdepth:
            if i[0]==element:
                req=True
                depth=i[1]

        if req==True:
            return depth
        else:
            return None
            

        
    def xml_to_bracket(self):
        'Convert input xml file to bracketed parse form'

        
        allelementsdepth=XmlTree.elements_depth(self)
        dlist=[]
        elist=[]
        for i in allelementsdepth:
            elist.append(i[0])
            dlist.append(i[1]) 
            
        Bparse=''
        Cdepth=0
        for i in (self.root).iter():
            index=elist.index(i)
            depth=dlist[index]
            
            if (type(i.text))==str:
                i.text=re.sub('\s+',' ',i.text)

            if depth>Cdepth:
                if i.text!='' and i.text!=None :
                    Bparse=Bparse+'('+i.tag+' '+i.text
                    Cdepth=depth
                else:    
                    Bparse=Bparse+'('+i.tag
                    Cdepth=depth

            else:
                n_bracket=(Cdepth-depth+1)*')'
                if i.text!='' and i.text!=None:
                    Bparse=Bparse+n_bracket+'('+i.tag+' '+i.text
                    Cdepth=depth
                else:
                    Bparse=Bparse+n_bracket+'('+i.tag
                    Cdepth=depth

                    
        Bparse=Bparse+(')'*Cdepth)
##        print(Bparse)
        return Bparse




    def element_to_bracket(element):
            'Gets a subtree of xml file and returns the bracket form'

            
            allelementsdepth=XmlTree.subtree_elements_depth(element)
            dlist=[]
            elist=[]
            for i in allelementsdepth:
                elist.append(i[0])
                dlist.append(i[1]) 
                
            Bparse=''
            Cdepth=0
            for i in element.iter():
                index=elist.index(i)
                depth=dlist[index]
                
                if (type(i.text))==str:
                    i.text=re.sub('\s+',' ',i.text)

                if depth>Cdepth:
                    if i.text!='' and i.text!=None :
                        Bparse=Bparse+'('+i.tag+' '+i.text
                        Cdepth=depth
                    else:    
                        Bparse=Bparse+'('+i.tag
                        Cdepth=depth

                else:
                    n_bracket=(Cdepth-depth+1)*')'
                    if i.text!='' and i.text!=None:
                        Bparse=Bparse+n_bracket+'('+i.tag+' '+i.text
                        Cdepth=depth
                    else:
                        Bparse=Bparse+n_bracket+'('+i.tag
                        Cdepth=depth
                        
            Bparse=Bparse+(')'*Cdepth)
    ##        print(Bparse)
            return Bparse




    def bracket_to_xml(bracketform,xmlroot=False,xmlfile=True,prettyxml=False):

        'Takes Bracketed form of a parsed sentence and returns xml format'
        'xml file is set to true by default which saves the result in an xml file named output.xml'
        'if xmlroot is set to true, the tree root would be returned instead of the whole tree'
        'if the prettyxml is set to true, code saves and returns the fianl tree in prettyxml format'
        'Pretty xml may cause problems, it is better to be avoided'
        'if there are any mistakes in bracketed form,the retunred result would be wrong; but there will be a result anyway!'
        'Even additional parenthesis around the root must be rmoved for a Correct Result'

        
##        bracketform=input('enter bracket form?  ')
        split=bracketform.split()

        string=''
        for i in split:
            temp=''
            for j in i:
                if j=='(' or j==')':
                    temp=temp+' '+j+' '

                else:
                    temp=temp+j

            string=string+temp+' '

        split=string.split()

        if (split.count('(')) != (split.count(')')):
            print('Bracketd parse is ill-formed, No. of opened & closed parenthesis does not match')
            return None

        else:

            root=None
            stack=[]
            depth=0
            templist=[]

            for i in range(len(split)):
                if split[i]=='(' and root==None:
                    temp=[]
                    root=ET.Element(split[i+1])
                    templist.append(split[i+1])
                    temp.append(root)
                    temp.append(depth)
                    stack.append(temp)
                    depth=depth+1

                elif split[i]=='(' and root!=None:
                    temp=[]
                    for j in stack:
                        if j[1]==depth-1:
                            templist.append(split[i+1])
                            elem=ET.SubElement(j[0],split[i+1])
                            temp.append(elem)
                            temp.append(depth)
                            depth=depth+1
                    stack.append(temp)

                elif split[i]==')':
                    depth=depth-1
                    stack.remove(stack[-1])

                else:
                    if templist.count(split[i])==0:
                        (stack[-1][0]).text=split[i]

            
            try:
            

                root
##                tree=ET.tostring(root,'UTF-8')

                if xmlroot==True:
                    return root

                else:
                    if prettyxml==True and xmlfile==True:
                        tree=ET.tostring(root,'UTF-8')
                        reparse=minidom.parseString(tree)
                        finaltree=reparse.toprettyxml(indent=" ")
                        with open('output.xml','w',encoding='UTF-8')as output:
                            output.write(finaltree)
                        return finaltree
                    

                    elif prettyxml==True and xmlfile==False:
                        tree=ET.tostring(root,'UTF-8')
                        reparse=minidom.parseString(tree)
                        finaltree=reparse.toprettyxml(indent=" ")
                        return finaltree
                        
                        
                    elif prettyxml==False and xmlfile==True:                      
                        xml=ET.ElementTree(root)
                        xml.write('output.xml',encoding='UTF-8')
                        return xml

                    else:
                        xml=ET.ElementTree(root)
                        return xml
                        
                    
                    

            except:
                print('bracketed parse is ill-formed!')
                print('Prettyxml may causes problems of different sorts and resutls in Failure','try with setting prettyxml to False')
                return None




    def element_subtree_text(element):
        'iters through the given element and retuns all found text in subtree'

        text=''
        for i in element.iter():
            if i.text!='' and i.text!=None:
                txt=i.text
                txt=re.sub('\s+','',txt)
                txt=re.sub(' +','\u200c',txt)
                text=text+txt+' '
        text=re.sub(' +',' ',text)
        text=re.sub('\s+$','',text)
        text=re.sub('^\s+','',text)

        return text


                
    def tree_view(self):
        'Visual representation of the xmlfile'
        
        bracket=XmlTree.xml_to_bracket(self)
        t=Tree.fromstring(bracket)
        t.draw()

        
    def element_treeview(element):
        'visual representation of a Subtree'

        bracket=XmlTree.element_to_bracket(element)
        t=Tree.fromstring(bracket)
        t.draw()
        


                
